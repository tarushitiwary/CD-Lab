int main() {
    int x = 5;
    float y = 2.5;
    if (x < y) {
        x = 10;
    }
}
