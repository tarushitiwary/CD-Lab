#include <stdio.h>
int main() {
    // This is a single-line comment
    int x = 10;
    float y = 5.5;
    if (x > y) {
        printf("x is greater than y\n");
    }
    return 0;
}
