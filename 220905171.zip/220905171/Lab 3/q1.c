#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

#define MAX_BUF_SIZE 100

int isKeyword(char *word) {
    const char *keywords[] = {
        "int", "float", "double", "char", "if", "else", "while", "for", "return", "void", "break", "continue"
    };
    for (int i = 0; i < 12; i++) {
        if (strcmp(word, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

void identifyArithmeticOperator(char c) {
    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '%') {
        printf("\nArithmetic operator: %c", c);
    }
}

void identifyRelationalOperator(char c, FILE *fp) {
    char buf[3] = {c, '\0', '\0'};
    if (c == '=' || c == '<' || c == '>' || c == '!') {
        char nextChar = fgetc(fp);
        if (nextChar == '=') {
            buf[1] = nextChar;
            buf[2] = '\0';
            if (c == '=') {
                printf("\nRelational operator: %s", buf);
            } else if (c == '<') {
                printf("\nRelational operator: %s", buf);
            } else if (c == '>') {
                printf("\nRelational operator: %s", buf);
            } else if (c == '!') {
                printf("\nRelational operator: %s", buf);
            }
        } else {
            ungetc(nextChar, fp);
            if (c == '<') {
                printf("\nRelational operator: <");
            } else if (c == '>') {
                printf("\nRelational operator: >");
            } else if (c == '=') {
                printf("\nRelational operator: =");
            } else if (c == '!') {
                printf("\nRelational operator: !");
            }
        }
    }
}

void identifyLogicalOperator(char c, FILE *fp) {
    if (c == '&') {
        char nextChar = fgetc(fp);
        if (nextChar == '&') {
            printf("\nLogical operator: &&");
        } else {
            ungetc(nextChar, fp);
        }
    } else if (c == '|') {
        char nextChar = fgetc(fp);
        if (nextChar == '|') {
            printf("\nLogical operator: ||");
        } else {
            ungetc(nextChar, fp);
        }
    }
}

void identifySpecialSymbols(char c) {
    if (c == '(' || c == ')' || c == '{' || c == '}' || c == '[' || c == ']' ||
        c == ';' || c == ',' || c == '.' || c == ':' || c == '?' || c == '#') {
        printf("\nSpecial symbol: %c", c);
    }
}

void identifyNumericalConstants(FILE *fp, char c) {
    if (isdigit(c)) {
        char numBuf[MAX_BUF_SIZE];
        int i = 0;
        numBuf[i++] = c;
        c = fgetc(fp);
        while (isdigit(c)) {
            numBuf[i++] = c;
            c = fgetc(fp);
        }
        numBuf[i] = '\0';
        ungetc(c, fp);
        printf("\nNumerical constant: %s", numBuf);
    }
}

void identifyStringLiterals(FILE *fp, char c) {
    if (c == '"') {
        char strBuf[MAX_BUF_SIZE];
        int i = 0;
        strBuf[i++] = c;
        c = fgetc(fp);
        while (c != '"' && c != EOF) {
            strBuf[i++] = c;
            c = fgetc(fp);
        }
        if (c == '"') {
            strBuf[i++] = c;
            strBuf[i] = '\0';
            printf("\nString literal: %s", strBuf);
        }
    }
}

void identifyIdentifiers(FILE *fp, char c) {
    if (isalpha(c) || c == '_') {
        char idBuf[MAX_BUF_SIZE];
        int i = 0;
        idBuf[i++] = c;
        c = fgetc(fp);
        while (isalnum(c) || c == '_') {
            idBuf[i++] = c;
            c = fgetc(fp);
        }
        idBuf[i] = '\0';
        ungetc(c, fp);
        if (isKeyword(idBuf)) {
            printf("\nKeyword: %s", idBuf);
        } else {
            printf("\nIdentifier: %s", idBuf);
        }
    }
}

int main() {
    char c;
    FILE *fp = fopen("digit.c", "r");
    if (fp == NULL) {
        printf("Cannot open file \n");
        exit(0);
    }

    c = fgetc(fp);
    while (c != EOF) {
        if (isspace(c)) {
            c = fgetc(fp);
            continue;
        }

        identifyArithmeticOperator(c);
        identifyRelationalOperator(c, fp);
        identifyLogicalOperator(c, fp);
        identifySpecialSymbols(c);
        identifyNumericalConstants(fp, c);
        identifyStringLiterals(fp, c);
        identifyIdentifiers(fp, c);

        c = fgetc(fp);
    }

    fclose(fp);
    return 0;
}
