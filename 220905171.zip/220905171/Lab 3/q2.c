#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_BUF_SIZE 100

typedef enum {
    KEYWORD, IDENTIFIER, OPERATOR, NUMBER, STRING_LITERAL, COMMENT, DIRECTIVE, SPECIAL_SYMBOL, UNKNOWN
} TokenType;

typedef struct {
    int row;
    int col;
    TokenType type;
    char value[MAX_BUF_SIZE];
} Token;

FILE *sourceFile;
int currentRow = 1, currentCol = 1;
char currentChar;

void getNextChar() {
    currentChar = fgetc(sourceFile);
    if (currentChar == '\n') {
        currentRow++;
        currentCol = 1;
    } else {
        currentCol++;
    }
}

int isKeyword(char *word) {
    const char *keywords[] = {
        "int", "float", "double", "char", "if", "else", "while", "for", "return", "void", "break", "continue"
    };
    for (int i = 0; i < 12; i++) {
        if (strcmp(word, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

void skipWhitespace() {
    while (isspace(currentChar)) {
        getNextChar();
    }
}

void skipSingleLineComment() {
    while (currentChar != '\n' && currentChar != EOF) {
        getNextChar();
    }
}

void skipMultiLineComment() {
    getNextChar();  
    while (!(currentChar == '*' && fgetc(sourceFile) == '/')) {
        getNextChar();
    }
}

Token getNextToken() {
    Token token;
    token.row = currentRow;
    token.col = currentCol;
    token.value[0] = '\0';  
    skipWhitespace();

    if (currentChar == EOF) {
        token.type = UNKNOWN;
        return token;
    }

    if (currentChar == '/') {
        char nextChar = fgetc(sourceFile);
        if (nextChar == '/') {
            skipSingleLineComment();
            return getNextToken();  
        } else if (nextChar == '*') {
            skipMultiLineComment();
            return getNextToken();  
        } else {
            ungetc(nextChar, sourceFile);  
            token.type = OPERATOR;
            token.value[0] = '/';
            return token;
        }
    }

    if (currentChar == '"') {
        int i = 0;
        token.type = STRING_LITERAL;
        token.value[i++] = currentChar;
        getNextChar();
        while (currentChar != '"' && currentChar != EOF) {
            token.value[i++] = currentChar;
            getNextChar();
        }
        if (currentChar == '"') {
            token.value[i++] = currentChar;
            token.value[i] = '\0';
            getNextChar();
        }
        return token;
    }

    if (currentChar == '#') {
        token.type = DIRECTIVE;
        token.value[0] = '#';
        getNextChar();
        return token;
    }

    if (isalpha(currentChar) || currentChar == '_') {
        int i = 0;
        token.type = IDENTIFIER;
        token.value[i++] = currentChar;
        getNextChar();
        while (isalnum(currentChar) || currentChar == '_') {
            token.value[i++] = currentChar;
            getNextChar();
        }
        token.value[i] = '\0';
        if (isKeyword(token.value)) {
            token.type = KEYWORD;
        }
        return token;
    }

    if (isdigit(currentChar)) {
        int i = 0;
        token.type = NUMBER;
        while (isdigit(currentChar)) {
            token.value[i++] = currentChar;
            getNextChar();
        }
        token.value[i] = '\0';
        return token;
    }

    if (currentChar == '+' || currentChar == '-' || currentChar == '*' || currentChar == '/' ||
        currentChar == '=' || currentChar == '<' || currentChar == '>' || currentChar == '%' || 
        currentChar == '!' || currentChar == '&' || currentChar == '|' || currentChar == '^' ||
        currentChar == '~') {
        token.type = OPERATOR;
        token.value[0] = currentChar;
        getNextChar();
        token.value[1] = '\0';
        return token;
    }

    if (currentChar == '(' || currentChar == ')' || currentChar == '{' || currentChar == '}' ||
        currentChar == '[' || currentChar == ']' || currentChar == ';' || currentChar == ',' ||
        currentChar == '.' || currentChar == ':' || currentChar == '?') {
        token.type = SPECIAL_SYMBOL;
        token.value[0] = currentChar;
        getNextChar();
        token.value[1] = '\0';
        return token;
    }

    token.type = UNKNOWN;
    return token;
}

void printToken(Token token) {
    const char *typeStr;
    switch (token.type) {
        case KEYWORD: typeStr = "KEYWORD"; break;
        case IDENTIFIER: typeStr = "IDENTIFIER"; break;
        case OPERATOR: typeStr = "OPERATOR"; break;
        case NUMBER: typeStr = "NUMBER"; break;
        case STRING_LITERAL: typeStr = "STRING_LITERAL"; break;
        case COMMENT: typeStr = "COMMENT"; break;
        case DIRECTIVE: typeStr = "DIRECTIVE"; break;
        case SPECIAL_SYMBOL: typeStr = "SPECIAL_SYMBOL"; break;
        case UNKNOWN: typeStr = "UNKNOWN"; break;
        default: typeStr = "UNKNOWN"; break;
    }
    printf("Row: %d, Col: %d, Type: %s, Value: %s\n", token.row, token.col, typeStr, token.value);
}

int main() {
    sourceFile = fopen("program.c", "r");
    if (sourceFile == NULL) {
        printf("Could not open file.\n");
        return 1;
    }

    getNextChar();
    while (1) {
        Token token = getNextToken();
        if (token.type == UNKNOWN) {
            break;
        }
        printToken(token);
    }

    fclose(sourceFile);
    return 0;
}

