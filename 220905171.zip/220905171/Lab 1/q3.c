#include<stdio.h>
#include<stdlib.h>

int main(){
	FILE *ftpr1, *ftpr2, *ftpr3;
	char filename[100], c1, c2;

	printf("Enter the first file to be opened: ");
	scanf("%s",filename);
	ftpr1 = fopen(filename,"r");
	if (ftpr1 == NULL){
		printf("Can't open file %s",filename);
		exit(0);
	}
	printf("Enter the second file to be opened: ");
	scanf("%s",filename);
	ftpr2 = fopen(filename,"r");
	if (ftpr2 == NULL){
		printf("Can't open file %s",filename);
		exit(0);
	}
	printf("Enter the destination file: ");
	scanf("%s",filename);
	ftpr3 = fopen(filename,"w+");
	if (ftpr3 == NULL){
		printf("Can't open file %s",filename);
		exit(0);
	}
	c1 = fgetc(ftpr1);
	c2 = fgetc(ftpr2);

	while(c1 != EOF || c2 != EOF){
		while(c1 != '\n' && c1 != EOF){
			fputc(c1,ftpr3);
			c1 = fgetc(ftpr1);
		}
		if(c1 == '\n'){
			fputc(c1,ftpr3);
		}
		c1 = fgetc(ftpr1);
		while(c2 != '\n' && c2 != EOF){
			fputc(c2,ftpr3);
			c2 = fgetc(ftpr2);
		}
		if(c2 == '\n'){
			fputc(c2, ftpr3);
		}
		c2 = fgetc(ftpr2);
		}
	printf("Done\n");
	fclose(ftpr1);
	fclose(ftpr2);
	fclose(ftpr3);
}