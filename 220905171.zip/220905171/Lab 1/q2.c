#include<stdio.h>
#include<stdlib.h>

int main(){
	FILE *ftpr1, *ftpr2;
	char filename[100],c;
	int n=0;

	printf("Enter the filename for reading: ");
	scanf("%s",filename);

	ftpr1 = fopen(filename, "r");
	if(ftpr1 == NULL){
		printf("Can't open file %s",filename);
		exit(0);
	}

	fseek(ftpr1,0,SEEK_END);
	n = ftell(ftpr1);
	rewind(ftpr1);

	printf("Enter the filename for writing: ");
	scanf("%s", filename);

	ftpr2 = fopen(filename, "w+");
	if (ftpr2 == NULL){
		printf("Can't open file %s",filename);
		fclose(ftpr1);
		exit(0);
	}

	for(int i=n-1; i>=0; i--){
		fseek(ftpr1,i,SEEK_SET);
		c = fgetc(ftpr1);
		fputc(c,ftpr2);
	}
	fclose(ftpr1);
	fclose(ftpr2);

	printf("Contents copied to %s\n", filename);
	printf("File size was: %d bytes\n", n);

}