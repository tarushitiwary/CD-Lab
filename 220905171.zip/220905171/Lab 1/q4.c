#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define TABLE_SIZE 10

typedef struct Node {
    char *verb;
    struct Node *next;
} Node;

Node *hashTable[TABLE_SIZE];

unsigned int hash(char *str) {
    unsigned int hashValue = 0;
    while (*str) {
        hashValue = (hashValue << 5) + *str;
        str++;
    }
    return hashValue % TABLE_SIZE;
}

int search(char *key) {
    unsigned int index = hash(key);
    Node *current = hashTable[index];

    while (current != NULL) {
        if (strcmp(current->verb, key) == 0) {
            return index;
        }
        current = current->next;
    }
    return -1;
}

void insert(char *str) {
    if (search(str) == -1) {
        unsigned int index = hash(str);
        Node *newNode = (Node *)malloc(sizeof(Node));
        newNode->verb = strdup(str);
        newNode->next = hashTable[index];
        hashTable[index] = newNode;
        printf("Inserted verb: '%s' at index %d\n", str, index);
    } else {
        printf("Verb '%s' already exists in the hash table.\n", str);
    }
}

int isVerb(char *word) {
    const char *verbs[] = {"run", "eat", "jump", "read", "write", "go", "sing", "dance", "speak", "see"};
    for (int i = 0; i < 10; i++) {
        if (strcmp(word, verbs[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

void processInput(char *input) {
    char *token = strtok(input, " ");

    while (token != NULL) {
        for (int i = 0; token[i]; i++) {
            token[i] = tolower(token[i]);
        }

        if (isVerb(token)) {
            insert(token);
        }
        token = strtok(NULL, " ");
    }
}

int main() {

    char input[200];
    for (int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i] = NULL;
    }

    printf("Enter a sentence: ");
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = 0;

    processInput(input);
    return 0;
}
