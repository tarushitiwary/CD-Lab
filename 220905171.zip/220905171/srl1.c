#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STACK_SIZE 100
#define MAX_INPUT_SIZE 100


#define NUM_TERMINALS 6
#define NUM_NON_TERMINALS 3

typedef enum {
    ID, PLUS, STAR, LPAREN, RPAREN, EOF_TOKEN
} Terminal;

typedef enum {
    E, T, F
} NonTerminal;


typedef struct {
    int stack[MAX_STACK_SIZE];
    int top;
} Stack;


void init_stack(Stack* s) {
    s->top = -1;
}


void push(Stack* s, int value) {
    if (s->top < MAX_STACK_SIZE - 1) {
        s->stack[++(s->top)] = value;
    }
}


int pop(Stack* s) {
    if (s->top >= 0) {
        return s->stack[(s->top)--];
    }
    return -1;  // Stack is empty
}

// Get the top of the stack
int peek(Stack* s) {
    if (s->top >= 0) {
        return s->stack[s->top];
    }
    return -1;  // Stack is empty
}

// Grammar rules in the form of production numbers
// 0 -> E -> E + T
// 1 -> E -> T
// 2 -> T -> T * F
// 3 -> T -> F
// 4 -> F -> ( E )
// 5 -> F -> id

int action_table[NUM_NON_TERMINALS][NUM_TERMINALS] = {
    // E, T, F, +, *, (, ), id, $
    {1, -1, -1, 0, -1, 0, 0, 1},  // E
    {-1, 2, 3, -1, -1, -1, -1, -1}, // T
    {-1, -1, -1, -1, -1, 4, 5, -1}, // F
};


int parse(const char* input) {
    Stack stack;
    init_stack(&stack);


    push(&stack, E);
    push(&stack, EOF_TOKEN);

    int idx = 0;
    Terminal current_token;
    char c;

    while (1) {
        c = input[idx];
        

        if (c == 'i' && input[idx + 1] == 'd') {
            current_token = ID;
            idx += 2;  // Move past 'id'
        } else if (c == '+') {
            current_token = PLUS;
            idx++;
        } else if (c == '*') {
            current_token = STAR;
            idx++;
        } else if (c == '(') {
            current_token = LPAREN;
            idx++;
        } else if (c == ')') {
            current_token = RPAREN;
            idx++;
        } else if (c == '$') {
            current_token = EOF_TOKEN;
            idx++;
        } else {
            return 0;  // Invalid character
        }

        int top = peek(&stack);

        if (top == current_token) {
            pop(&stack);  // Match terminal, pop from stack
        } else if (top >= E && top <= F) {
            // Non-terminal, apply the action based on the parsing table
            int action = action_table[top][current_token];
            if (action == -1) {
                return 0;  // Syntax error
            }


            switch (action) {
                case 0: // E -> E + T
                    push(&stack, T);
                    push(&stack, PLUS);
                    push(&stack, E);
                    break;
                case 1: // E -> T
                    push(&stack, T);
                    break;
                case 2: // T -> T * F
                    push(&stack, F);
                    push(&stack, STAR);
                    push(&stack, T);
                    break;
                case 3: // T -> F
                    push(&stack, F);
                    break;
                case 4: // F -> ( E )
                    push(&stack, RPAREN);
                    push(&stack, E);
                    push(&stack, LPAREN);
                    break;
                case 5: // F -> id
                    push(&stack, ID);
                    break;
                default:
                    return 0;  
            }
        } else {
            return 0;  
        }


        if (peek(&stack) == EOF_TOKEN && current_token == EOF_TOKEN) {
            break;  
        }
    }

    return 1;  
}

int main() {
    const char* input = "id+id*id$";

    if (parse(input)) {
        printf("Parsing successful!\n");
    } else {
        printf("Parsing failed!\n");
    }

    return 0;
}

