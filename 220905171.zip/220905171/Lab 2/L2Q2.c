#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fa, *fb;
    int ca;

    fa = fopen("input.c", "r");
    if (fa == NULL) {
        printf("Cannot open input file\n");
        exit(0);
    }

    fb = fopen("output.c", "w");
    if (fb == NULL) {
        printf("Cannot open output file\n");
        fclose(fa); 
        exit(0);
    }

    ca = getc(fa);
    while (ca != EOF) {
        if (ca == '#') {
            while (ca != '\n' && ca != EOF) {
                ca = getc(fa);
            }
        } else {
            putc(ca, fb);
        }
        ca = getc(fa);
    }

    fclose(fa);
    fclose(fb);

    printf("Preprocessor directives discarded successfully.\n");

    return 0;
}
