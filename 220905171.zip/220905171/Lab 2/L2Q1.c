#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fa, *fb;
    int c;

    fa = fopen("input.txt", "r");
    if (fa == NULL) {
        printf("Cannot open input file\n");
        exit(0);
    }

    fb = fopen("output.txt", "w");
    if (fb == NULL) {
        printf("Cannot open output file\n");
        exit(0);
    }

    c = getc(fa);
    int in_space_or_tab = 0;  

    while (c != EOF) {
        if (c == ' ' || c == '\t') {
            if (!in_space_or_tab) {
                putc(' ', fb);
                in_space_or_tab = 1;
            }
        } else {
            putc(c, fb);
            in_space_or_tab = 0;
        }
        c = getc(fa);
    }
    fclose(fa);
    fclose(fb);

    printf("File processing complete. Output written to output.txt\n");

    return 0;
}
