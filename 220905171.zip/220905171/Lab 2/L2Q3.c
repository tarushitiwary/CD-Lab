#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int is_keyword(const char *word) {
    const char *keywords[] = {
        "auto", "break", "case", "char", "const", "continue", "default", "do",
        "double", "else", "enum", "extern", "for", "goto", "if", "inline", "int",
        "long", "register", "restrict", "return", "short", "signed", "sizeof", 
        "static", "struct", "switch", "typedef", "union", "unsigned", "void", 
        "volatile", "while", NULL
    };
    
    for (int i = 0; keywords[i] != NULL; i++) {
        if (strcmp(word, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

void process_file(FILE *fa, FILE *fb) {
    int c;
    char word[100];
    int word_index = 0;

    while ((c = getc(fa)) != EOF) {
        if (isalnum(c) || c == '_') {
            word[word_index++] = (char)c;
        } else {
            if (word_index > 0) {
                word[word_index] = '\0';
                if (is_keyword(word)) {
                    for (int i = 0; i < word_index; i++) {
                        word[i] = toupper(word[i]);
                    }
                }
                fputs(word, fb);
                word_index = 0;
            }
            putc(c, fb);
        }
    }
}

int main() {
    FILE *fa, *fb;

    fa = fopen("input.c", "r");
    if (fa == NULL) {
        printf("Cannot open input file\n");
        exit(0);
    }

    fb = fopen("output.c", "w");
    if (fb == NULL) {
        printf("Cannot open output file\n");
        fclose(fa);
        exit(0);
    }

    process_file(fa, fb);

    fclose(fa);
    fclose(fb);

    printf("C program processed successfully. Keywords converted to uppercase.\n");

    return 0;
}
