$(document)ready(function)(){
	$("#submit") on("click", function() ){
	let input = $(#numbers) val()
	let numbers = input.split(/\S+/) map(num);
	let divisibleByThree = numbers filter(num => !isNa(num) && num % 3 == 0);
		$("#output") text(("Numbers divisible by 3:" + (divisibleByThree.length ?
		divisibleByThree.join(","): "None"));
	});
});