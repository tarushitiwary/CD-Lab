#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_BUF_SIZE 100
#define TABLE_SIZE 50  // Size of the hash table

typedef enum {
    KEYWORD, IDENTIFIER, OPERATOR, NUMBER, STRING_LITERAL, COMMENT, DIRECTIVE, SPECIAL_SYMBOL, UNKNOWN
} TokenType;

typedef enum {
    LOCAL
} SymbolType;

typedef struct {
    int row;
    int col;
    TokenType type;
    char value[MAX_BUF_SIZE];
} Token;

typedef struct {
    char name[MAX_BUF_SIZE];
    SymbolType symbolType;
    int row;
    int col;
    int isOccupied;  // To mark whether the slot is occupied or deleted
} Symbol;

Symbol localSymbolTable[TABLE_SIZE];  // Local symbol table array

FILE *sourceFile;
int currentRow = 1, currentCol = 1;
char currentChar;

// Hash function for the symbol table (using a simple hashing method)
unsigned int hash(char *str) {
    unsigned int hashValue = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        hashValue = (hashValue * 31) + str[i];  // Simple hash function (polynomial rolling hash)
    }
    return hashValue % TABLE_SIZE;
}

void getNextChar() {
    currentChar = fgetc(sourceFile);
    if (currentChar == '\n') {
        currentRow++;
        currentCol = 1;
    } else {
        currentCol++;
    }
}

int isKeyword(char *word) {
    const char *keywords[] = {
        "int", "float", "double", "char", "if", "else", "while", "for", "return", "void", "break", "continue", "main"
    };
    for (int i = 0; i < 12; i++) {
        if (strcmp(word, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

void skipWhitespace() {
    while (isspace(currentChar)) {
        getNextChar();
    }
}

void skipSingleLineComment() {
    while (currentChar != '\n' && currentChar != EOF) {
        getNextChar();
    }
}

void skipMultiLineComment() {
    getNextChar();  
    while (!(currentChar == '*' && fgetc(sourceFile) == '/')) {
        getNextChar();
    }
}

Token getNextToken() {
    Token token;
    token.row = currentRow;
    token.col = currentCol;
    token.value[0] = '\0';  
    skipWhitespace();

    if (currentChar == EOF) {
        token.type = UNKNOWN;
        return token;
    }

    if (currentChar == '/') {
        char nextChar = fgetc(sourceFile);
        if (nextChar == '/') {
            skipSingleLineComment();
            return getNextToken();  
        } else if (nextChar == '*') {
            skipMultiLineComment();
            return getNextToken();  
        } else {
            ungetc(nextChar, sourceFile);  
            token.type = OPERATOR;
            token.value[0] = '/';
            return token;
        }
    }

    if (currentChar == '"') {
        int i = 0;
        token.type = STRING_LITERAL;
        token.value[i++] = currentChar;
        getNextChar();
        while (currentChar != '"' && currentChar != EOF) {
            token.value[i++] = currentChar;
            getNextChar();
        }
        if (currentChar == '"') {
            token.value[i++] = currentChar;
            token.value[i] = '\0';
            getNextChar();
        }
        return token;
    }

    if (currentChar == '#') {
        token.type = DIRECTIVE;
        token.value[0] = '#';
        getNextChar();
        return token;
    }

    if (isalpha(currentChar) || currentChar == '_') {
        int i = 0;
        token.type = IDENTIFIER;
        token.value[i++] = currentChar;
        getNextChar();
        while (isalnum(currentChar) || currentChar == '_') {
            token.value[i++] = currentChar;
            getNextChar();
        }
        token.value[i] = '\0';
        if (isKeyword(token.value)) {
            token.type = KEYWORD;
        }
        return token;
    }

    if (isdigit(currentChar)) {
        int i = 0;
        token.type = NUMBER;
        while (isdigit(currentChar)) {
            token.value[i++] = currentChar;
            getNextChar();
        }
        token.value[i] = '\0';
        return token;
    }

    if (currentChar == '+' || currentChar == '-' || currentChar == '*' || currentChar == '/' ||
        currentChar == '=' || currentChar == '<' || currentChar == '>' || currentChar == '%' || 
        currentChar == '!' || currentChar == '&' || currentChar == '|' || currentChar == '^' ||
        currentChar == '~') {
        token.type = OPERATOR;
        token.value[0] = currentChar;
        getNextChar();
        token.value[1] = '\0';
        return token;
    }

    if (currentChar == '(' || currentChar == ')' || currentChar == '{' || currentChar == '}' ||
        currentChar == '[' || currentChar == ']' || currentChar == ';' || currentChar == ',' ||
        currentChar == '.' || currentChar == ':' || currentChar == '?') {
        token.type = SPECIAL_SYMBOL;
        token.value[0] = currentChar;
        getNextChar();
        token.value[1] = '\0';
        return token;
    }

    token.type = UNKNOWN;
    return token;
}

void addSymbol(char *name, SymbolType symbolType, int row, int col) {
    unsigned int index = hash(name);

    // Use closed hashing to find the next available slot
    while (localSymbolTable[index].isOccupied) {
        if (strcmp(localSymbolTable[index].name, name) == 0) {
            // If symbol already exists, no need to add it again
            return;
        }
        index = (index + 1) % TABLE_SIZE;  // Linear probing
    }

    // Insert the symbol
    strcpy(localSymbolTable[index].name, name);
    localSymbolTable[index].symbolType = symbolType;
    localSymbolTable[index].row = row;
    localSymbolTable[index].col = col;
    localSymbolTable[index].isOccupied = 1;  // Mark as occupied
}

int isSymbolInTable(char *name) {
    unsigned int index = hash(name);
    
    while (localSymbolTable[index].isOccupied) {
        if (strcmp(localSymbolTable[index].name, name) == 0) {
            return 1;
        }
        index = (index + 1) % TABLE_SIZE;  // Linear probing
    }
    return 0;
}

void printToken(Token token) {
    const char *typeStr;
    switch (token.type) {
        case KEYWORD: typeStr = "KEYWORD"; break;
        case IDENTIFIER: typeStr = "IDENTIFIER"; break;
        case OPERATOR: typeStr = "OPERATOR"; break;
        case NUMBER: typeStr = "NUMBER"; break;
        case STRING_LITERAL: typeStr = "STRING_LITERAL"; break;
        case COMMENT: typeStr = "COMMENT"; break;
        case DIRECTIVE: typeStr = "DIRECTIVE"; break;
        case SPECIAL_SYMBOL: typeStr = "SPECIAL_SYMBOL"; break;
        case UNKNOWN: typeStr = "UNKNOWN"; break;
        default: typeStr = "UNKNOWN"; break;
    }
    printf("Row: %d, Col: %d, Type: %s, Value: %s\n", token.row, token.col, typeStr, token.value);
}

int main() {
    sourceFile = fopen("program.c", "r");
    if (sourceFile == NULL) {
        printf("Could not open file.\n");
        return 1;
    }

    // Initialize the symbol table
    for (int i = 0; i < TABLE_SIZE; i++) {
        localSymbolTable[i].isOccupied = 0;  // Mark all entries as empty initially
    }

    getNextChar();
    while (1) {
        Token token = getNextToken();
        if (token.type == UNKNOWN) {
            break;
        }

        // If the token is an identifier, add it to the symbol table
        if (token.type == IDENTIFIER) {
            if (!isSymbolInTable(token.value)) {
                addSymbol(token.value, LOCAL, token.row, token.col);
            }
        }

        printToken(token);
    }

    fclose(sourceFile);

    // Print the local symbol table
    printf("\nLocal Symbol Table:\n");
    for (int i = 0; i < TABLE_SIZE; i++) {
        if (localSymbolTable[i].isOccupied) {
            printf("Name: %s, Type: LOCAL, Row: %d, Col: %d\n", localSymbolTable[i].name,
                   localSymbolTable[i].row, localSymbolTable[i].col);
        }
    }

    fclose(sourceFile);
    return 0;
}
