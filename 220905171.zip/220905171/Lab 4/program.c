#include <stdio.h>

int main() {
    int x = 10;
    float y = 20.5;
    char z = 'A';

    printf("Hello, World!\n");
    return 0;
}
